using Microsoft.AspNetCore.Mvc;

namespace Forms.Controllers
{
    public class FormController : Controller
    {
        // Render the Index Page
        [HttpGet]
        [Route("")]
        public ViewResult Index() {
            return View();
        }


        // Render the Results Page
        [HttpPost]
        [Route("result")]
        public ViewResult Result(string name, string location, string language, string comment)
        {
            ViewBag.name = name;
            ViewBag.location = location;
            ViewBag.language = language;
            ViewBag.comment = comment;
            return View();
        }
    }
}