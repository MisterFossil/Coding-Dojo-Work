namespace ModelFun.Models
{
    public class Message
    {
        public string Text {get; set;}
    }

    public class Numbers
    {
        public int[] nums {get;set;}
    }

    public class Users
    {
        public string[] userList {get;set;}
    }

    
}