using Microsoft.AspNetCore.Mvc;

namespace Portfolio.Controllers {

    public class PortfolioController : Controller {
        // Adding Routes for this controller to handle

        // index
        [HttpGet]
        [Route("")]
        public string Index() {
            return "This is my index!";
        }

        // projects
        [HttpGet]
        [Route("projects")]
        public string Projects() {
            return "These are my projects!";
        }

        // contact
        [HttpGet]
        [Route("contact")]
        public string Contact(){
            return "This is my contact!";
        }
    }
}