using Microsoft.AspNetCore.Mvc;

namespace ProfileRedux.Controllers
{
    public class HelloController : Controller
    {
        // index route
        [HttpGet]
        [Route("")]
        public string Index()
        {
            return "This is the index!";
        }

        // projects render
        [HttpGet]
        [Route("projects")]
        public string Projects()
        {
            return "These are my projects.";
        }

        // contact render
        [HttpGet]
        [Route("contact")]
        public string Contact()
        {
            return "This is my Contact!";
        }

    }
}