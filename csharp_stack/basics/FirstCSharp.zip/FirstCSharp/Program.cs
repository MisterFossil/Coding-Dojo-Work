﻿using System;

namespace FirstCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("This is the first line of C# doe with Coding Dojo!");
        }
    }
}
