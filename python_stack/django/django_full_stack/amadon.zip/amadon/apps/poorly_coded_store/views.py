from django.shortcuts import render, redirect
from .models import Order, Product

def index(request):
    context = {
        "all_products": Product.objects.all()
    }
    return render(request, "store/index.html", context)

def checkout(request):
    # quantity_from_form = int(request.POST["quantity"])
    # price_from_form = float(request.POST["price"])
    # total_charge = quantity_from_form * price_from_form
    # request.session.setdefault('overall_p', 0)
    # request.session['overall_p'] += total_charge
    # request.session.setdefault('overall_q', 0)
    # request.session['overall_q'] += quantity_from_form
    context = {
        'quantity': request.session['quantity'],
        'price': request.session['price'],
        'total': request.session['total'],

    }
    print("Charging credit card...")
    Order.objects.create(quantity_ordered=request.session['quantity'], total_price=request.session['total'])
    return render(request, "store/checkout.html", context)

def ringUp(request):
    print('went through ringup')
    request.session['quantity'] = int(request.POST["quantity"])
    # quantity_from_form = int(request.POST["quantity"])
    request.session['price'] = float(request.POST["price"])
    # price_from_form = float(request.POST["price"])
    request.session['total'] = request.session['price'] * request.session['quantity']
    # total_charge = quantity_from_form * price_from_form
    request.session.setdefault('overall_p', 0)
    request.session['overall_p'] += request.session['total']
    request.session.setdefault('overall_q', 0)
    request.session['overall_q'] += request.session['quantity']
    return redirect('/checkout')