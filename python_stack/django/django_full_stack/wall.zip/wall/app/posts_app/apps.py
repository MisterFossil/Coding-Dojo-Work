from django.apps import AppConfig


class PostsAppConfig(AppConfig):
    name = 'posts_app'
