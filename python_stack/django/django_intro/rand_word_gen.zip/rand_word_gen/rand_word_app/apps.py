from django.apps import AppConfig


class RandWordAppConfig(AppConfig):
    name = 'rand_word_app'
