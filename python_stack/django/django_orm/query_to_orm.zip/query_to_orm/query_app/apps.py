from django.apps import AppConfig


class QueryAppConfig(AppConfig):
    name = 'query_app'
